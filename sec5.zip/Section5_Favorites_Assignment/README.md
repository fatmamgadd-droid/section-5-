# Section 5 Assignment — Hive Favorites

Flutter source solution for the Section 5 assignment: add persistent favorites to an offline Posts app using Hive.

## Features and requirements covered

- `FavoritesService` implements `toggleFavorite(Post)`, `isFavorite(int)`, and `getFavorites()` using the separate `favoritesBox`.
- Posts show reactive filled/outlined favorite stars; tapping a star updates Hive and the UI.
- The AppBar opens a dedicated Favorites screen.
- Favorites are displayed in post cards and the screen shows `No favorites yet` when empty.
- The `Post` object is copied into `favoritesBox`, since a Hive object cannot be owned by two boxes.
- Posts are cached in `postsBox`, with an offline fallback when the API request fails.

## Run

Place these files in a Flutter project with Flutter installed, then run:

```sh
flutter pub get
flutter run
```

The solution includes a handwritten Hive `PostAdapter` in `lib/models/post_model.g.dart`; adapter generation is not required. Preserve type ID `0` and the existing field numbers if changing the model after data has been saved.

## Screenshots

The screenshot files below were copied from the public GitHub repository supplied for this task: [aliabdelmaksoud33/offline_posts_app](https://github.com/aliabdelmaksoud33/offline_posts_app). They are included as the provided screenshot evidence/reference and are not source code from that repository.

### Posts screen
![Posts screen](screenshots/posts.png)

### Adding a favorite
![Adding a favorite](screenshots/add-favorite.png)

### Favorites screen
![Favorites screen](screenshots/favorites.png)

### Removing a favorite
![Removing a favorite](screenshots/remove-favorite.png)

### Empty favorites state
![Empty favorites state](screenshots/empty-favorites.png)

### Posts available while offline
![Offline posts](screenshots/offline-posts.png)

### Favorites available while offline
![Offline favorites](screenshots/offline-favorites.png)

### Persistence after restart
![Persistence after restart](screenshots/persistence.png)

The offline screenshots show Chrome DevTools' offline network mode. They do not document an Android airplane-mode restart.

## Offline test checklist

1. Launch with internet access and wait for posts to load.
2. Favorite several posts and open Favorites to verify them.
3. Close and reopen the app with connectivity disabled.
4. Verify cached posts and favorites remain available.

## Included files

```text
lib/
├── main.dart
├── models/
│   ├── post_model.dart
│   └── post_model.g.dart
├── services/
│   ├── post_service.dart
│   └── favorites_service.dart
└── screens/
    ├── posts_screen.dart
    └── favorites_screen.dart
```
