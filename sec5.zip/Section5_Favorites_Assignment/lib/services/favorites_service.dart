import 'package:hive/hive.dart';

import '../models/post_model.dart';

class FavoritesService {
  static const String boxName = 'favoritesBox';

  Box<Post> get _box => Hive.box<Post>(boxName);

  /// Adds a copy of [post] to favorites or removes it if already saved.
  /// A copy is required because a HiveObject cannot belong to two boxes.
  Future<void> toggleFavorite(Post post) async {
    if (_box.containsKey(post.id)) {
      await _box.delete(post.id);
      return;
    }

    final copy = Post(
      id: post.id,
      title: post.title,
      body: post.body,
      userId: post.userId,
    );
    await _box.put(post.id, copy);
  }

  bool isFavorite(int id) => _box.containsKey(id);

  /// Reads favorites synchronously from the already-opened Hive box.
  List<Post> getFavorites() => _box.values.toList(growable: false);
}
