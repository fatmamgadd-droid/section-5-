import 'dart:convert';

import 'package:hive/hive.dart';
import 'package:http/http.dart' as http;

import '../models/post_model.dart';

class PostService {
  static const String apiUrl = 'https://jsonplaceholder.typicode.com/posts';
  static const String boxName = 'postsBox';

  Future<List<Post>> getPosts() async {
    final box = Hive.box<Post>(boxName);

    try {
      final response = await http
          .get(Uri.parse(apiUrl))
          .timeout(const Duration(seconds: 10));

      if (response.statusCode != 200) {
        throw http.ClientException(
          'Posts API returned HTTP ${response.statusCode}',
        );
      }

      final decoded = jsonDecode(response.body) as List<dynamic>;
      final onlinePosts = decoded
          .map((item) => Post.fromJson(item as Map<String, dynamic>))
          .toList(growable: false);

      // Refresh only postsBox; favoritesBox is separate and remains untouched.
      await box.clear();
      for (final post in onlinePosts) {
        await box.put(post.id, post);
      }

      print('Loaded from API and cached to Hive: ${onlinePosts.length}');
      return onlinePosts;
    } catch (error) {
      print('API unavailable; trying Hive cache. Reason: $error');
      if (box.isNotEmpty) {
        print('Loaded from Hive offline: ${box.length}');
        return box.values.toList(growable: false);
      }
      throw Exception('No Internet and No Cached Data');
    }
  }
}
